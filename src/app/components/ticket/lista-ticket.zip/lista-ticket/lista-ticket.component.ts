import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Ticket } from '../../../models/ticket/ticket';
import { TicketService } from '../../../services/ticket/ticket.service';

@Component({
  selector: 'app-lista-ticket',
  standalone: true,
  imports: [CommonModule, FormsModule],
  templateUrl: './lista-ticket.component.html',
  styleUrl: './lista-ticket.component.css'
})
export class ListaTicketComponent {
//ATRIBUTO
listaTicket:Array<Ticket>;
obTicket:Ticket;

//CONSTRUCTOR
constructor(private ticketService:TicketService){
  this.listaTicket=new Array<Ticket>();
  this.obTicket=new Ticket();
  this.obtenerTickets();
}

//METODOS
//Obtener todos los tickets
obtenerTickets():void{
  this.ticketService.obtenetTickets().subscribe(
    (ultado:any)=>{
      this.listaTicket=ultado;
      console.log("MI OBJETO");
      console.log(ultado);
      console.log(this.listaTicket);
    }
  )
}

//eliminar un ticket
eliminarUnTicket(id:string):void{
  this.ticketService.eliminarTicket(id).subscribe(
    (ultado:any)=>{
      console.log("Se eliminara:" +id);
      console.log("Ticket Eliminado");
      this.obtenerTickets();
    }

  )
}

//
modificarTicket(id:string, ticket:Ticket):void{
  this.ticketService.modificarTicket(id,ticket).subscribe(
    (ultado:any)=>{
      this.obtenerTickets();
    }
  )
}
}
